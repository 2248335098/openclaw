
import os
import time
from datetime import datetime
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process
from langchain.tools import tool
from langchain_openai import ChatOpenAI
from apscheduler.schedulers.blocking import BlockingScheduler
import json

# 加载环境变量
load_dotenv()

# 配置LLM模型（可替换为本地模型或其他厂商API）
llm = ChatOpenAI(
    model="gpt-4o",
    api_key=os.getenv("OPENAI_API_KEY"),
    base_url=os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
)

# ===================== 工具定义 =====================
# 模拟游戏运营系统的各类工具，实际使用时可替换为真实API调用

@tool
def query_game_data(metric: str, time_range: str = "last_24h") -> str:
    """
    查询游戏核心运营数据
    :param metric: 要查询的指标，可选值：dau, retention, arpu, churn_rate, activity_rate
    :param time_range: 时间范围，如 last_24h, last_7d, last_30d
    """
    # 模拟数据，实际项目中替换为数据库查询或数据API调用
    mock_data = {
        "dau": {"last_24h": 125800, "last_7d": 132400, "last_30d": 128900},
        "retention": {"last_24h": 0.42, "last_7d": 0.35, "last_30d": 0.28},
        "arpu": {"last_24h": 85.6, "last_7d": 82.3, "last_30d": 79.8},
        "churn_rate": {"last_24h": 0.052, "last_7d": 0.048, "last_30d": 0.045},
        "activity_rate": {"last_24h": 0.78, "last_7d": 0.75, "last_30d": 0.72}
    }
    if metric not in mock_data:
        return f"未知指标: {metric}"
    value = mock_data[metric].get(time_range, "无数据")
    return json.dumps({
        "metric": metric,
        "time_range": time_range,
        "value": value,
        "timestamp": datetime.now().isoformat()
    })

@tool
def monitor_server_status() -> str:
    """
    监控游戏服务器的运行状态，包括CPU、内存、网络、在线人数等
    """
    # 模拟服务器状态数据
    return json.dumps({
        "server_status": "healthy",
        "cpu_usage": 0.62,
        "memory_usage": 0.58,
        "network_bandwidth": "1.2Gbps",
        "online_players": 125800,
        "db_connection": "normal",
        "timestamp": datetime.now().isoformat()
    })

@tool
def search_knowledge_base(query: str) -> str:
    """
    搜索游戏知识库，用于客服回答玩家问题
    :param query: 用户的问题
    """
    # 模拟知识库搜索，实际项目中替换为向量数据库检索
    knowledge_base = {
        "怎么找回密码": "您可以在登录页面点击'忘记密码'，通过绑定的手机号或邮箱重置密码",
        "充值不到账": "请您提供订单号，我们会在10分钟内为您核实处理，正常情况下充值会在5分钟内到账",
        "怎么加入公会": "您可以在主城找到公会管理员，或者点击社交面板中的公会按钮申请加入",
        "副本掉落": "不同难度的副本掉落不同品质的装备，英雄难度副本有几率掉落史诗装备",
        "防沉迷": "根据国家规定，未成年用户每日游戏时长不得超过1.5小时，节假日不得超过3小时"
    }
    # 简单匹配，实际项目中使用语义搜索
    for key, answer in knowledge_base.items():
        if key in query:
            return answer
    return "未找到相关信息，已为您转接人工客服"

@tool
def push_notification(user_ids: list, content: str) -> str:
    """
    向指定用户推送游戏内通知或邮件
    :param user_ids: 目标用户ID列表
    :param content: 推送内容
    """
    # 模拟推送，实际项目中替换为推送服务API
    return f"已成功向 {len(user_ids)} 位用户推送通知: {content[:50]}..."

@tool
def audit_content(content: str) -> str:
    """
    审核社区内容或聊天内容，检测违规信息
    :param content: 待审核的内容
    """
    # 模拟内容审核，实际项目中可对接内容安全API
    sensitive_words = ["外挂", "作弊", "赌博", "诈骗", "广告"]
    for word in sensitive_words:
        if word in content:
            return f"检测到违规内容: 包含敏感词 '{word}'"
    return "内容审核通过"

# ===================== Agent定义 =====================

# 1. 运营经理Agent
operation_manager = Agent(
    role="游戏运营团队经理",
    goal="统筹协调所有运营Agent的工作，汇总运营信息，生成运营报告，保障游戏稳定高效运行",
    backstory="""你是一位拥有10年MMORPG游戏运营经验的资深经理，
    你擅长团队协调、任务分配和信息汇总，能够快速识别运营中的问题并调度合适的人员处理。
    你每天都会汇总所有团队成员的工作汇报，生成清晰的每日运营简报，让管理层一目了然当前的运营状态。
    你会确保所有的运营任务都能高效协同，不会出现信息孤岛或重复工作。""",
    verbose=True,
    allow_delegation=True,
    llm=llm
)

# 2. 数据监控Agent
data_monitor = Agent(
    role="数据监控分析师",
    goal="7x24小时监控游戏核心运营指标，自动识别数据异常，及时发现运营问题并触发告警",
    backstory="""你是一位专业的数据分析师，对游戏运营数据极其敏感。
    你负责监控DAU、留存率、ARPU、流失率等核心指标，能够快速识别数据的异常波动。
    当发现数据异常时，你会第一时间通知运营经理，并给出初步的原因分析。
    你每天都会生成数据监控报告，让团队了解当前的用户和收入状况。""",
    verbose=True,
    allow_delegation=False,
    tools=[query_game_data],
    llm=llm
)

# 3. 用户运营Agent
user_operation = Agent(
    role="用户运营专家",
    goal="负责用户生命周期管理，用户分层运营，流失用户召回，提升用户留存和活跃",
    backstory="""你是一位资深的用户运营专家，擅长用户分层和精细化运营。
    你会根据用户的行为数据，将用户分为新手、核心、付费、流失风险等不同群体。
    针对不同群体，你会制定个性化的运营策略，比如为流失风险用户推送召回礼包，为新手用户提供引导。
    你致力于提升用户的留存率和活跃度，让更多玩家愿意留在游戏中。""",
    verbose=True,
    allow_delegation=True,
    tools=[query_game_data, push_notification],
    llm=llm
)

# 4. 活动运营Agent
event_operation = Agent(
    role="活动运营策划",
    goal="负责游戏活动的策划、配置、上线和复盘，持续为玩家提供新鲜的游戏内容",
    backstory="""你是一位创意十足的活动策划，擅长设计有趣的游戏活动。
    你会根据当前的运营数据，设计合适的活动来提升用户活跃和收入。
    你负责活动的全流程管理，从策划、配置、上线到效果复盘。
    你还负责游戏的内容更新和公告发布，确保玩家能够及时了解最新的游戏动态。
    你会避免游戏出现长草期，让玩家始终有新的内容可以体验。""",
    verbose=True,
    allow_delegation=True,
    tools=[query_game_data, push_notification],
    llm=llm
)

# 5. 智能客服Agent
customer_service = Agent(
    role="智能客服专员",
    goal="自动处理玩家的咨询和投诉，快速响应玩家问题，提升玩家服务体验",
    backstory="""你是一位耐心细致的客服专员，擅长处理玩家的各种问题。
    你采用多级分诊机制，简单的常见问题直接自动回复，复杂问题转交给人工客服。
    你会使用知识库来快速回答玩家的问题，确保玩家的问题能够得到及时解决。
    你还会收集玩家的反馈，整理后提交给运营团队，帮助优化游戏体验。""",
    verbose=True,
    allow_delegation=True,
    tools=[search_knowledge_base],
    llm=llm
)

# 6. 风控Agent
risk_control = Agent(
    role="风控安全专家",
    goal="保障游戏生态安全，反作弊检测，异常交易监控，内容审核，维护游戏经济平衡",
    backstory="""你是游戏的安全守护者，负责维护游戏的公平性和生态稳定。
    你会检测玩家的异常行为，识别外挂和作弊玩家，及时进行处罚。
    你监控游戏内的交易系统，防止金币交易、洗钱等破坏经济系统的行为。
    你还负责社区内容的审核，过滤违规信息，维护健康的社区环境。
    你会确保所有玩家都能在公平的环境中享受游戏。""",
    verbose=True,
    allow_delegation=False,
    tools=[audit_content, query_game_data],
    llm=llm
)

# 7. 运维Agent
devops = Agent(
    role="技术运维工程师",
    goal="保障游戏服务器稳定运行，自动处理故障，弹性扩容，数据备份",
    backstory="""你是一位经验丰富的运维工程师，负责游戏服务器的稳定运行。
    你7x24小时监控服务器的状态，包括CPU、内存、网络等指标。
    当服务器出现负载过高时，你会自动进行弹性扩容，保障玩家的流畅体验。
    你会定期进行数据备份，确保数据安全，当出现故障时能够快速恢复。
    你会确保游戏服务器不会宕机，让玩家能够随时进入游戏。""",
    verbose=True,
    allow_delegation=False,
    tools=[monitor_server_status],
    llm=llm
)

# ===================== 任务定义 =====================

# 日常数据监控任务
daily_data_monitor_task = Task(
    description="""
    完成今日的游戏运营数据监控，检查核心指标DAU、7日留存、ARPU、流失率的当前值和波动情况。
    识别是否存在数据异常，如果有异常请标记出来并给出初步分析。
    生成今日的数据监控报告。
    """,
    expected_output="今日数据监控报告，包含各核心指标的数值、波动情况、异常告警（如有）",
    agent=data_monitor
)

# 日常服务器运维任务
daily_devops_task = Task(
    description="""
    完成今日的服务器状态巡检，检查所有服务器的CPU、内存、网络、在线人数等状态。
    检查是否存在故障风险，是否需要扩容或优化。
    确认数据备份任务是否正常完成。
    生成今日的运维报告。
    """,
    expected_output="今日运维报告，包含服务器状态、风险提示、备份情况",
    agent=devops
)

# 日常风控巡检任务
daily_risk_control_task = Task(
    description="""
    完成今日的风控安全巡检，检查是否有新增的作弊账号，是否有异常交易行为。
    检查今日的社区内容审核情况，是否有违规内容。
    检查游戏经济系统的状态，金币产出和消耗是否平衡。
    生成今日的风控报告。
    """,
    expected_output="今日风控报告，包含作弊检测、交易监控、内容审核情况",
    agent=risk_control
)

# 用户运营分析任务
user_analysis_task = Task(
    description="""
    基于今日的用户数据，分析用户的分层情况，识别流失风险用户。
    针对流失风险用户，制定个性化的召回策略，准备召回通知内容。
    分析新手用户的留存情况，是否需要优化新手引导。
    生成今日的用户运营报告。
    """,
    expected_output="今日用户运营报告，包含用户分层、流失预警、召回策略",
    agent=user_operation
)

# 活动运营复盘任务
event_analysis_task = Task(
    description="""
    复盘当前正在进行的活动的效果，分析活动的参与率、收入贡献、用户反馈。
    如果当前没有活动，策划下一个适合的活动，根据当前的运营数据设计活动规则和奖励。
    准备活动的公告内容。
    生成今日的活动运营报告。
    """,
    expected_output="今日活动运营报告，包含活动复盘或新活动策划方案",
    agent=event_operation
)

# 运营简报汇总任务
daily_briefing_task = Task(
    description="""
    汇总所有Agent的今日报告，包括数据监控、运维、风控、用户运营、活动运营的所有信息。
    整理成一份清晰的每日运营简报，突出重点信息和需要关注的问题。
    按照重要程度排序，让管理层能够快速了解今日的运营状态。
    """,
    expected_output="完整的每日运营简报，结构化展示所有运营信息，重点突出异常和待办事项",
    agent=operation_manager
)

# ===================== 日常运营流程 =====================
def run_daily_operation():
    """
    执行每日运营流程
    """
    print(f"[{datetime.now()}] 开始执行每日运营巡检...")
    
    # 创建Crew，执行所有日常任务
    crew = Crew(
        agents=[
            data_monitor, devops, risk_control, 
            user_operation, event_operation, operation_manager
        ],
        tasks=[
            daily_data_monitor_task,
            daily_devops_task,
            daily_risk_control_task,
            user_analysis_task,
            event_analysis_task,
            daily_briefing_task
        ],
        process=Process.sequential,
        verbose=True
    )
    
    # 执行任务
    result = crew.kickoff()
    
    # 输出结果
    print(f"[{datetime.now()}] 每日运营巡检完成！")
    print("="*50)
    print("每日运营简报:")
    print(result)
    print("="*50)
    
    # 实际项目中，这里可以将简报发送到邮箱或企业微信
    return result

# ===================== 异常处理流程 =====================
def handle_anomaly(anomaly_type: str, anomaly_data: dict):
    """
    处理运营异常情况
    :param anomaly_type: 异常类型，比如: user_churn_spike, server_overload, cheat_detection
    :param anomaly_data: 异常的详细数据
    """
    print(f"[{datetime.now()}] 检测到异常: {anomaly_type}，启动应急处理流程...")
    
    # 根据异常类型，调度对应的Agent处理
    if anomaly_type == "user_churn_spike":
        # 流失率异常，调度用户运营和活动运营处理
        task = Task(
            description=f"""
            当前检测到用户流失率异常上升，数据为: {anomaly_data}
            请分析流失率上升的原因，制定紧急的用户召回策略，设计临时召回活动。
            协调客服Agent准备好相关的咨询回复。
            """,
            expected_output="异常流失处理方案，包含原因分析、召回策略、活动方案",
            agent=operation_manager
        )
        
        crew = Crew(
            agents=[operation_manager, user_operation, event_operation, customer_service],
            tasks=[task],
            process=Process.hierarchical,
            verbose=True
        )
        
    elif anomaly_type == "server_overload":
        # 服务器过载，调度运维Agent处理
        task = Task(
            description=f"""
            当前服务器检测到过载，状态数据为: {anomaly_data}
            请立即进行扩容处理，优化服务器负载，保障玩家体验。
            检查是否有异常流量攻击，做好防护。
            """,
            expected_output="服务器过载处理结果，包含扩容情况、负载优化结果",
            agent=devops
        )
        
        crew = Crew(
            agents=[devops, operation_manager],
            tasks=[task],
            process=Process.sequential,
            verbose=True
        )
        
    elif anomaly_type == "cheat_detection":
        # 检测到作弊，调度风控Agent处理
        task = Task(
            description=f"""
            检测到大规模作弊行为，数据为: {anomaly_data}
            请立即处理这些作弊账号，封禁违规账号，更新反作弊规则。
            检查是否有漏洞被利用，及时修复。
            """,
            expected_output="作弊事件处理报告，包含账号处理、规则更新、漏洞修复情况",
            agent=risk_control
        )
        
        crew = Crew(
            agents=[risk_control, operation_manager],
            tasks=[task],
            process=Process.sequential,
            verbose=True
        )
    
    # 执行异常处理
    result = crew.kickoff()
    
    print(f"[{datetime.now()}] 异常处理完成！")
    print("处理结果:")
    print(result)
    
    return result

# ===================== 客服咨询处理 =====================
def handle_player_query(player_id: str, query: str):
    """
    处理玩家的咨询
    :param player_id: 玩家ID
    :param query: 玩家的问题
    """
    print(f"[{datetime.now()}] 收到玩家 {player_id} 的咨询: {query}")
    
    task = Task(
        description=f"""
        玩家 {player_id} 咨询了问题: {query}
        请处理这个玩家的咨询，首先搜索知识库找到答案，如果找不到就转人工。
        回复要友好、清晰，符合游戏客服的语气。
        """,
        expected_output="给玩家的回复内容",
        agent=customer_service
    )
    
    crew = Crew(
        agents=[customer_service],
        tasks=[task],
        verbose=True
    )
    
    result = crew.kickoff()
    
    print(f"回复玩家: {result}")
    return result

# ===================== 定时任务相关 =====================
def hourly_server_check():
    """每小时执行一次服务器状态检查"""
    status = monitor_server_status()
    print(f"[{datetime.now()}]  hourly server check: {status}")

def start_scheduler():
    """
    启动定时任务调度器，每日自动执行运营巡检
    """
    scheduler = BlockingScheduler()
    
    # 每日早上6点执行每日运营巡检
    scheduler.add_job(run_daily_operation, 'cron', hour=6, minute=0)
    
    # 每小时执行一次服务器状态检查
    scheduler.add_job(hourly_server_check, 'interval', hours=1)
    
    print("定时任务调度器已启动，等待执行...")
    print("每日6:00自动执行每日运营巡检")
    print("每小时自动执行服务器状态检查")
    
    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        pass

# ===================== 主函数 =====================
if __name__ == "__main__":
    print("="*60)
    print("MMORPG游戏运营全链路自动化助手 MVP 已启动")
    print("="*60)
    
    # 示例1：手动执行一次日常运营流程
    print("\n=== 执行示例：手动触发每日运营巡检 ===")
    run_daily_operation()
    
    # 示例2：处理玩家咨询
    print("\n=== 执行示例：处理玩家咨询 ===")
    handle_player_query("player_12345", "请问怎么找回我的账号密码？")
    
    # 示例3：模拟异常处理
    print("\n=== 执行示例：模拟流失异常处理 ===")
    handle_anomaly(
        anomaly_type="user_churn_spike",
        anomaly_data={"churn_rate": 0.12, "normal_rate": 0.05, "affected_users": 1250}
    )
    
    # 启动定时任务（取消注释即可启动后台定时任务）
    # print("\n=== 启动定时任务调度器 ===")
    # start_scheduler()
